<?php
if ( ! function_exists( 'freemius_sdk' ) ) {
    // Create a helper function for easy SDK access.
    function freemius_sdk() {
        global $freemius_sdk;

        if ( ! isset( $freemius_sdk ) ) {
            // Include Freemius SDK.
            require_once dirname(__FILE__) . '/freemius/start.php';

            $freemius_sdk = fs_dynamic_init( array(
                'id'                  => '16305',
                'slug'                => 'wp-affiliate-defense',
                'premium_slug'        => 'wp-affiliate-defense',
                'type'                => 'plugin',
                'public_key'          => 'pk_d568f63693357e9be9d71beec9c85',
                'is_premium'          => true,
                'is_premium_only'     => true,
                'has_addons'          => false,
                'has_paid_plans'      => true,
                'is_org_compliant'    => false,
                'trial'               => array(
                    'days'               => 10,
                    'is_require_payment' => false,
                ),
                'menu'                => array(
                    'first-path'     => 'plugins.php',
                    'contact'        => false,
                    'support'        => false,
                ),
            ) );
        }

        return $freemius_sdk;
    }

    // Init Freemius.
    freemius_sdk();
    // Signal that SDK was initiated.
    do_action( 'freemius_sdk_loaded' );
}